var userLives;
var userLives1
var playerGuess = '';
var chosenWord = '';
var playerGuessedAtLeastOneLetter = false;
var chosenWord;
var guessedLetter;
var randomWords;
var e;
var i;
var space = " ";

var jsAnswerRack0 = document.getElementById("answerRack0");
var	jsAnswerRack1 = document.getElementById("answerRack1");
var	jsAnswerRack2 = document.getElementById("answerRack2");
var	jsAnswerRack3 = document.getElementById("answerRack3");
var	jsAnswerRack4 = document.getElementById("answerRack4");
var	jsAnswerRack5 = document.getElementById("answerRack5");
var	jsAnswerRack6 = document.getElementById("answerRack6");
var	jsAnswerRack7 = document.getElementById("answerRack7");



var newGame = function() {
	chosenWord = getRandomWord();
	console.log("Notice: New Game Started");
	userLives = 5;
	lengthChecker(); // makes number of underscores the same as number of letters in chosenWord
};


var guessChecker = function() {
	
	console.log("chosenWord = " + chosenWord);

	for (i=0; i<chosenWord.length; i++){
		if (chosenWord[i] === playerGuess){ // player made a correct guess
			playerGuessedAtLeastOneLetter = true;
			guessedLetter = i;
			console.log(guessedLetter);
			console.log(i);
			console.log("Congrats!!");
			showAnswerRack(); // put correct letter in answer rack
			
		}
	}

	if (playerGuessedAtLeastOneLetter === false) { // player made an incorrect guess
		userLives--;

		userLives1 = document.getElementById("lives"); // lower userlives on page
		userLives1.innerHTML = userLives;

		console.log("Commiserations");
		console.log(userLives);
		console.log("userLives = " + userLives);
		if (userLives === 0) {
			alert("Game Over. Starting again");
			location.reload();
		}
	}
	playerGuessedAtLeastOneLetter = false;
};



var getRandomWord = function(){ //RANDOM WORD GENERATOR
	console.log("Notice: getRandomWord function activated");
	//var correctGuesses = [];
	randomWords = ["arses", "bottom", "bumhole"]; //pick a random word
	e = (Math.floor(Math.random()*randomWords.length));//random number generator=

	return randomWords[e];
};


var buttonClicked = function (allDataFromHTML) {// TAKES THE LETTER THAT WAS CLICKED ON
	playerGuess = allDataFromHTML.innerHTML;
	allDataFromHTML.disabled = true;
	
	console.log("Player Guess = " + playerGuess)
	console.log("Notice: buttonClicked function activated");

	guessChecker(); 

};






var start = function(){ //Overall function
	newGame();	

};


var showAnswerRack = function() {

// I could turn this whole thing into a single script (updates dynamically) so that it could be in a line.
// Needs to be able to work with words from approx 4-9 letters


var jsAnswerRack0 = document.getElementById("answerRack0");
var	jsAnswerRack1 = document.getElementById("answerRack1");
var	jsAnswerRack2 = document.getElementById("answerRack2");
var	jsAnswerRack3 = document.getElementById("answerRack3");
var	jsAnswerRack4 = document.getElementById("answerRack4");
var	jsAnswerRack5 = document.getElementById("answerRack5");
var	jsAnswerRack6 = document.getElementById("answerRack6");
var	jsAnswerRack7 = document.getElementById("answerRack7");
// var space = "";

// jsAnswerRack0.innerHTML = space; // hides all the underscores on showAnswerRack
// jsAnswerRack1.innerHTML = space;
// jsAnswerRack2.innerHTML = space;
// jsAnswerRack3.innerHTML = space;
// jsAnswerRack4.innerHTML = space;
// jsAnswerRack5.innerHTML = space;
// jsAnswerRack6.innerHTML = space;

//if chosenWord.length === 4 

	console.log("guessedLetter = " + guessedLetter + " (" + chosenWord[guessedLetter] + ")");
	
	if (i === 0) {
		jsAnswerRack0.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack0 = " + chosenWord[guessedLetter]);
	}

	else if (i === 1) {
		jsAnswerRack1.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack1 = " + chosenWord[guessedLetter]);
	}

	else if (i === 2) {
		jsAnswerRack2.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack2 = " + chosenWord[guessedLetter]);
	}

	else if (i === 3) {
		jsAnswerRack3.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack3 = " + chosenWord[guessedLetter]);
	}

	else if (i === 4) {
		jsAnswerRack4.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack4 = " + chosenWord[guessedLetter]);
	}

	else if (i === 5) {
		jsAnswerRack5.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack5 = " + chosenWord[guessedLetter]);
	}

	else if (i === 6) {
		jsAnswerRack6.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack6 = " + chosenWord[guessedLetter]);
	}

	else if (i === 7) {
		jsAnswerRack7.innerHTML = chosenWord[guessedLetter];
	console.log("jsAnswerRack7 = " + chosenWord[guessedLetter]);
	}

};

var incorrectGuessesRack = function() {
// have a new div rack showing incorrect answers struck through.
};

var lengthChecker = function() {

var jsAnswerRack0 = document.getElementById("answerRack0");
var	jsAnswerRack1 = document.getElementById("answerRack1");
var	jsAnswerRack2 = document.getElementById("answerRack2");
var	jsAnswerRack3 = document.getElementById("answerRack3");
var	jsAnswerRack4 = document.getElementById("answerRack4");
var	jsAnswerRack5 = document.getElementById("answerRack5");
var	jsAnswerRack6 = document.getElementById("answerRack6");
var	jsAnswerRack7 = document.getElementById("answerRack7");
	
	if (chosenWord.length === 5) {
 		jsAnswerRack5.innerHTML = space;
 		jsAnswerRack6.innerHTML = space;
 		jsAnswerRack7.innerHTML = space;
	}

	if (chosenWord.length === 6) {
 		jsAnswerRack6.innerHTML = space;
 		jsAnswerRack7.innerHTML = space;
	}

	if (chosenWord.length === 7) {
 		jsAnswerRack7.innerHTML = space;
	}

}



// var doesThisLetterExist = function() {// IS PLAYERGUESS EQUAL TO ANY OF THE LETTERS IN CHOSENWORD (AT ALL). 
// 											// Note: Does not know which.
	
// 	playerGuessedAtLeastOneLetter = false;
	
// 	for (var i=0; i<chosenWord.length; i++){	
// 		if (chosenWord[i] === playerGuess){
// 			playerGuessedAtLeastOneLetter = true;
// 			// mark guesses in answer rack with guessed letter
// 		} else { 
			
// 		}	
// 	}
// 		// if (playerGuessedAtLeastOneLetter = false) {
// 		// 		userLives--;
// 		// 		console.log("userlives =" + userLives);
// 		// }


// 	if (playerGuessedAtLeastOneLetter === true) {
// 		alert("Congrats!");
// 	}
// };


// To do:

// Set up a rack for the answers. Blanks and guesed letters only.

//make letters unavailable after click (positive or negative)